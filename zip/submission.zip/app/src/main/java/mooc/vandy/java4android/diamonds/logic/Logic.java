package mooc.vandy.java4android.diamonds.logic;

import mooc.vandy.java4android.diamonds.ui.OutputInterface;

/**
 * This is where the logic of this App is centralized for this assignment.
 * <p>
 * The assignments are designed this way to simplify your early
 * Android interactions.  Designing the assignments this way allows
 * you to first learn key 'Java' features without having to beforehand
 * learn the complexities of Android.
 */
public class Logic
       implements LogicInterface {
    /**
     * This is a String to be used in Logging (if/when you decide you
     * need it for debugging).
     */
    public static final String TAG = Logic.class.getName();

    /**
     * This is the variable that stores our OutputInterface instance.
     * <p>
     * This is how we will interact with the User Interface [MainActivity.java].
     * <p>
     * It is called 'out' because it is where we 'out-put' our
     * results. (It is also the 'in-put' from where we get values
     * from, but it only needs 1 name, and 'out' is good enough).
     */
    private OutputInterface mOut;

    /**
     * This is the constructor of this class.
     * <p>
     * It assigns the passed in [MainActivity] instance (which
     * implements [OutputInterface]) to 'out'.
     */
    public Logic(OutputInterface out){
        mOut = out;
    }

    /**
     * This is the method that will (eventually) get called when the
     * on-screen button labeled 'Process...' is pressed.
     */
    public void process(int size) {
        // TODO -- add your code here

        int acc = -(size+1);
        int h = size * 2 + 1;
        int w = size * 2 + 2;


        for(int rows=1; rows<=h; rows++){
            acc++;
            for (int cols=1; cols<=w; cols++) {
                if((rows == 1 || rows == h) && (cols == 1 || cols == w))
                    mOut.print("+");
                else if((rows == 1 || rows == h) && !(cols == 1 || cols == w))
                    mOut.print("-");
                else if(!(rows == 1 || rows == h) && (cols == 1 || cols == w))
                    mOut.print("|");
                else {
                    
                    pattern(size, rows, cols, acc);
                }
            }
            mOut.print("\n");
        }

    }

    // TODO -- add any helper methods here
    public void pattern(int size, int i, int j, int acc){
        int diamondRowThickness;

        if (acc <= 0){
            diamondRowThickness = i*2-2;
        } else {
            diamondRowThickness = (i-acc*2)*2-2;
        }
        int diamondMidpoint = size + 1;
        int DboundL = diamondMidpoint - (diamondRowThickness/2-1);
        int DboundR= diamondMidpoint + (diamondRowThickness/2);
        int top = 1;
        int down = size * 2 + 1;

        if (j >= DboundL && j <= DboundR) {
            if (j == DboundL || j == DboundR) {
                if (i < diamondMidpoint && i > top) {
                    if (j == DboundL) {
                        mOut.print("/");
                    } else {
                        mOut.print("\\");
                    }
                } else if (i == diamondMidpoint) {
                    if (j == DboundL) {
                        mOut.print("<");
                    } else {
                        mOut.print(">");
                    }
                } else if (i > diamondMidpoint && i < down) {
                    if (j == DboundL) {
                        mOut.print("\\");
                    } else {
                        mOut.print("/");
                    }
                }
            } else {
                if (i % 2 == 0) {
                    mOut.print("=");
                } else{
                    mOut.print("-");
                }
            }
        } else {
            mOut.print(" ");
        }
    }
    
}
